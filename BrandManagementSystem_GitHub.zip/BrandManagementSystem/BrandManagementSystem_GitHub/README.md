# Brand Management System

نظام شامل لإدارة المصروفات، الإيرادات، العملاء، المخزون، والمبيعات.

## المميزات
- تسجيل دخول وصلاحيات
- تصدير PDF / Excel
- إرسال تقارير بالبريد
- تنبيهات وتنبيهات المخزون
- دعم رفع المرفقات
- واجهة حديثة باستخدام Bootstrap 5

## لتشغيل النظام محليًا
```bash
pip install -r requirements.txt
python run.py
```

## لتشغيله على Replit أو PythonAnywhere
تأكد من إعداد `requirements.txt` وملف `wsgi.py` عند الحاجة.